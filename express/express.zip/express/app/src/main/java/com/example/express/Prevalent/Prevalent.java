package com.example.express.Prevalent;

import com.example.express.Model.Users;

public class Prevalent
{



    public static Users currentOnlineUser;
    public static String UserPhoneKey = "UserPhone";
    public static String UserPasswordKey =  "UserPassword";







}
